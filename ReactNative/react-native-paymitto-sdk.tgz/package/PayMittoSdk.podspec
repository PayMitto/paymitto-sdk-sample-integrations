require "json"

package = JSON.parse(File.read(File.join(__dir__, "package.json")))

# Version of the native PayMitto iOS SDK (paymitto-ios-spm) this wrapper pins.
# Tracked separately from the wrapper version in package.json.
paymitto_ios_sdk_version = "11.0.2"

Pod::Spec.new do |s|
  s.name         = "PayMittoSdk"
  s.version      = package["version"]
  s.summary      = package["description"]
  s.homepage     = package["homepage"]
  s.license      = package["license"]
  s.authors      = package["author"]

  s.platforms    = { :ios => "16.0" }
  s.source       = { :git => "https://github.com/PayMitto/paymitto-ios-spm.git", :tag => paymitto_ios_sdk_version }
  s.module_name  = "RNPayMittoSdk"

  s.source_files = "ios/**/*.{h,m,mm,cpp,swift}"
  s.exclude_files = "ios/Frameworks/**"
  s.private_header_files = "ios/**/*.h"

  s.dependency "React-Core"
  s.dependency "ReactCommon/turbomodule/core"

  install_modules_dependencies(s)

  spm_dependency(s,
    url: 'https://github.com/PayMitto/paymitto-ios-spm',
    requirement: { kind: 'exactVersion', version: paymitto_ios_sdk_version },
    products: ['PayMittoSDK']
  )
end
