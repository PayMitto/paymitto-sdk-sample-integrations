require "json"

package = JSON.parse(File.read(File.join(__dir__, "package.json")))

Pod::Spec.new do |s|
  s.name         = "PayMittoSdk"
  s.version      = package["version"]
  s.summary      = package["description"]
  s.homepage     = package["homepage"]
  s.license      = package["license"]
  s.authors      = package["author"]

  s.platforms    = { :ios => "16.0" }
  s.source       = { :git => "https://github.com/PayMitto/paymitto-ios-spm.git", :tag => "#{s.version}" }
  s.module_name  = "RNPayMittoSdk"

  s.source_files = "ios/**/*.{h,m,mm,cpp,swift}"
  s.exclude_files = "ios/Frameworks/**"
  s.private_header_files = "ios/**/*.h"

  s.dependency "React-Core"
  s.dependency "ReactCommon/turbomodule/core"

  install_modules_dependencies(s)

  spm_dependency(s,
    url: 'https://github.com/PayMitto/paymitto-ios-spm',
    requirement: { kind: 'exactVersion', version: s.version.to_s },
    products: ['PayMittoSDK']
  )
end
