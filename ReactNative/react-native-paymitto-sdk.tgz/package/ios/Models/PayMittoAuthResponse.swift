//
//  PayMittoAuthResponse.swift
//  Pods
//
//  Created by Lucas Bordini on 11/7/25.
//

import PayMittoSDK

struct PayMittoAuthResponse: PayMittoSDK.AccessTokenDetails {
  let accessToken: String
  let expiresIn: Int
  let scope: String
  let tokenType: String
}
