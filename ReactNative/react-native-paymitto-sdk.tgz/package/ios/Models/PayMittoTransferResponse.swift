//
//  PayMittoTransferResponse.swift
//  Pods
//
//  Created by Lucas Bordini on 11/7/25.
//

import PayMittoSDK

struct PayMittoTransferResponse: PayMittoSDK.TransferDetails {
  let transferId: String
}
