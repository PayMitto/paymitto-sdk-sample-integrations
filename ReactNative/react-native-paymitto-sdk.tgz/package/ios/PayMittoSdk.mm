#import "PayMittoSdk.h"
#import <objc/message.h>
#if __has_include(<PayMittoSdk/PayMittoSdk-Swift.h>)
#import <PayMittoSdk/PayMittoSdk-Swift.h>
#elif __has_include("PayMittoSdk-Swift.h")
#import "PayMittoSdk-Swift.h"
#endif

@implementation PayMittoSdk
{
  BOOL _hasListeners;
  id moduleImpl;
}

- (instancetype)init
{
  self = [super init];
  if (self) {
    Class implClass = NSClassFromString(@"PayMittoSdkImpl");
    if (implClass != Nil) {
      moduleImpl = [implClass new];
    } else {
      NSLog(@"PayMittoSdkImpl not found. Check Swift header import.");
      moduleImpl = nil;
    }
  }
  return self;
}


- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params
{
    return std::make_shared<facebook::react::NativePayMittoSdkSpecJSI>(params);
}

+ (NSString *)moduleName
{
  return @"PayMittoSdk";
}

- (NSArray<NSString *> *)supportedEvents
{
  return @[
    @"PAYMITTO_AUTH_TOKEN_REQUESTED",
    @"PAYMITTO_TRANSFER_SUBMITTED",
    @"PAYMITTO_SDK_LAUNCHED",
    @"PAYMITTO_SDK_CLOSED"
  ];
}

+ (BOOL)requiresMainQueueSetup
{
  return NO;
}

- (void)startObserving
{
  _hasListeners = YES;
  NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
  [center addObserver:self selector:@selector(handleEventNotification:) name:@"PAYMITTO_AUTH_TOKEN_REQUESTED" object:nil];
  [center addObserver:self selector:@selector(handleEventNotification:) name:@"PAYMITTO_TRANSFER_SUBMITTED" object:nil];
  [center addObserver:self selector:@selector(handleEventNotification:) name:@"PAYMITTO_SDK_LAUNCHED" object:nil];
  [center addObserver:self selector:@selector(handleEventNotification:) name:@"PAYMITTO_SDK_CLOSED" object:nil];
}

- (void)stopObserving
{
  _hasListeners = NO;
  [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)addListener:(nonnull NSString *)eventName {
  [super addListener:eventName];
}

- (void)removeListeners:(double)count {
  [super removeListeners:count];
}

- (void)handleEventNotification:(NSNotification *)notification
{
  if (!_hasListeners) { return; }
  NSString *eventName = notification.name;
  id body = notification.userInfo ?: @{};
  [self sendEventWithName:eventName body:body];
}

- (void)onAccessTokenResponse:(NSDictionary * _Nullable)token error:(NSDictionary * _Nullable)error { 
  SEL sel = NSSelectorFromString(@"onAccessTokenResponse:error:");
  if (moduleImpl && [moduleImpl respondsToSelector:sel]) {
    ((void(*)(id, SEL, NSDictionary *, NSDictionary *))objc_msgSend)(moduleImpl, sel, token, error);
  } else {
    NSLog(@"Access Token Response (no impl)");
  }
}

- (void)onTransferResponse:(NSDictionary * _Nullable)response error:(NSDictionary * _Nullable)error { 
  SEL sel = NSSelectorFromString(@"onTransferResponse:error:");
  if (moduleImpl && [moduleImpl respondsToSelector:sel]) {
    ((void(*)(id, SEL, NSDictionary *, NSDictionary *))objc_msgSend)(moduleImpl, sel, response, error);
  } else {
    NSLog(@"Transfer Response (no impl): %@, Error: %@", response, error);
  }
}



- (void)startSDK:(nonnull NSDictionary *)config { 
  SEL sel = NSSelectorFromString(@"startSDK:");
  if (moduleImpl && [moduleImpl respondsToSelector:sel]) {
    ((void(*)(id, SEL, NSDictionary *))objc_msgSend)(moduleImpl, sel, config);
  } else {
    NSLog(@"Starting SDK with config (no impl): %@", config);
  }
}

- (void)startTransferDetails:(nonnull NSDictionary *)config transferId:(nonnull NSString *)transferId { 
  SEL sel = NSSelectorFromString(@"startTransferDetails:transferId:");
  if (moduleImpl && [moduleImpl respondsToSelector:sel]) {
    ((void(*)(id, SEL, NSDictionary *, NSString *))objc_msgSend)(moduleImpl, sel, config, transferId);
  } else {
    NSLog(@"Starting Transfer Details (no impl) for ID: %@ with config: %@", transferId, config);
  }
}

@end
