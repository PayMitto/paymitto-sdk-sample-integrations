//
//  PayMitto+ReactNative.swift
//  ReactNative
//
//  Created by Lucas Bordini on 9/29/25.
//

import PayMittoSDK

extension PayMittoSDK.TransferRequest {


  func toDictionary() -> [String: Any] {
    return [
      "quoteBy": quoteBy,
      "quoteHistoryId": quoteHistoryId,
      "recipientId": recipientId,
      "recipientAccountId": recipientAccountId as Any,
      "sourceAccountId": sourceAccountId as Any,
      "fields": fields?.toDictionaryArray() ?? []
    ]
  }

}

extension PayMittoSDK.RequestField {

  func toDictionary() -> [String: String] {
    return [
      "id": id,
      "value": value,
      "type": type
    ]
  }
}

extension Array where Element == PayMittoSDK.RequestField {

  func toDictionaryArray() -> [[String: String]] {
    return self.map { $0.toDictionary() }
  }
}
