import PayMittoSDK
import Foundation

/// Utility struct for converting React Native configuration to PayMitto SDK configuration
struct ConfigurationConverter {
    
    /// Main method to convert TypeScript configuration to Swift Configuration
    /// - Parameter config: Dictionary containing the configuration from TypeScript
    /// - Returns: Swift Configuration object with converted values
    /// - Note: Uses safe defaults for any missing or invalid configuration values
    func convert(_ config: [String: Any]) -> PayMittoConfiguration {
        let defaultCountry = convertDefaultCountry(config["defaultCountry"] as? String)
        let environment = convertEnvironment(config["environment"])
        let remittanceServiceProvider = convertRemittanceServiceProvider(config["remittanceServiceProvider"] as? String)
        let transferMethod = convertTransferMethod(config["transferMethod"] as? String)
        let idleTimeoutInterval: TimeInterval? = (config["idleTimeoutInterval"] as? NSNumber).map { $0.doubleValue }
        let localization = convertLocalization(config["localization"])
        let sourceAccounts = convertSourceAccounts(config["sourceAccounts"] as? [[String: Any]])
        let supportedAppearance = convertSupportedAppearance(config["supportedAppearance"] as? String)
        
        return PayMittoConfiguration(
            defaultCountry: defaultCountry,
            environment: environment,
            fixedRemittanceServiceProvider: remittanceServiceProvider,
            fixedTransferMethod: transferMethod,
            idleTimeoutInterval: idleTimeoutInterval,
            localization: localization,
            supportedAppearance: supportedAppearance,
            virtualSenderAccounts: sourceAccounts
        )
    }
    
    /// Extracts the appearance JSON string from the configuration
    /// - Parameter config: Dictionary containing the configuration from TypeScript
    /// - Returns: JSON string representation of the appearance, or nil if not provided
    func extractAppearanceJSON(_ config: [String: Any]) -> String? {
        guard let appearance = config["appearance"] as? [String: Any] else {
            return nil
        }
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: appearance, options: [])
            return String(data: jsonData, encoding: .utf8)
        } catch {
            return nil
        }
    }
    
    // MARK: - Enum Conversion Methods
    
    /// Convert TypeScript environment string to Swift PayMittoEnvironment
    private func convertEnvironment(_ env: Any?) -> PayMittoSDK.PayMittoEnvironment {
        guard let env = env as? String else { return .default }
        let trimmed = env.trimmingCharacters(in: .whitespacesAndNewlines)
        let lower = trimmed.lowercased()
        switch lower {
        case "production": return .production
        case "sandbox": return .sandbox
        default:
            // Support TS enum values 'PRODUCTION' and 'SANDBOX'
            switch trimmed.uppercased() {
            case "PRODUCTION": return .production
            case "SANDBOX": return .sandbox
            default: return .default
            }
        }
    }
    
    /// Convert TypeScript localization string to Swift Localization
    private func convertLocalization(_ locale: Any?) -> PayMittoSDK.Localization {
        guard let locale = locale as? String else { return .default }
        let trimmed = locale.trimmingCharacters(in: .whitespacesAndNewlines)
        let lower = trimmed.lowercased()
        switch lower {
        case "en-us", "enus": return .enUS
        case "es-mx", "esmx": return .esMX
        default: return .default
        }
    }
    
    /// Convert TypeScript transfer method string to Swift TransferMethod
    private func convertTransferMethod(_ transferMethodString: String?) -> TransferMethod? {
        guard let transferMethodString = transferMethodString else { return nil }
        
        return switch transferMethodString {
        case "bankAccount": .bankAccount
        case "cashPickup": .cashPickup
        case "mobileWallet": .mobileWallet
        case "pushToCard": .pushToCard
        default: nil
        }
    }
    
    /// Convert TypeScript remittance service provider string to Swift RemittanceServiceProvider
    private func convertRemittanceServiceProvider(_ providerString: String?) -> RemittanceServiceProvider? {
        guard let providerString = providerString else { return nil }
        return switch providerString {
        case "convera": .convera
        case "mastercard": .mastercard
        case "moneyGram": .moneyGram
        case "visa": .visa
        default: nil
        }
    }
    
    /// Convert TypeScript default country string to Swift DefaultCountry
    private func convertDefaultCountry(_ countryString: String?) -> DefaultCountry? {
        guard let countryString = countryString else { return nil }
        return DefaultCountry(iso3Code: countryString)
    }
    
    /// Convert TypeScript supported appearance string to Swift SupportedAppearance
    private func convertSupportedAppearance(_ appearanceString: String?) -> SupportedAppearance {
        guard let appearanceString = appearanceString else { return .default }
        let lower = appearanceString.lowercased()
        switch lower {
        case "light": return .light
        case "dark": return .dark
        case "device": return .device
        default: return .default
        }
    }
    
    /// Convert TypeScript source accounts array to Swift SourceAccount array
    private func convertSourceAccounts(_ accountsArray: [[String: Any]]?) -> [SourceAccount]? {
        guard let accountsArray = accountsArray else { return nil }
        
        return accountsArray.compactMap { accountDict in
            guard let alias = accountDict["alias"] as? String,
                  let balance = accountDict["balance"] as? Double,
                  let last4 = accountDict["last4"] as? String,
                  let sourceProviderId = accountDict["sourceProviderId"] as? String else {
                return nil
            }
            
            return SourceAccount(
                alias: alias,
                balance: balance,
                last4: last4,
                sourceProviderId: sourceProviderId
            )
        }
    }
}
