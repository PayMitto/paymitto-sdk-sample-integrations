#import <PayMittoSdkSpec/PayMittoSdkSpec.h>
#import <React/RCTEventEmitter.h>

@interface PayMittoSdk : RCTEventEmitter <NativePayMittoSdkSpec>

@end
