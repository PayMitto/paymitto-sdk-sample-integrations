package com.paymitto.reactnative.wrapper

import com.paymitto.android.sdk.PayMitto
import com.paymitto.android.sdk.PayMittoError
import com.paymitto.android.sdk.AccessTokenDetails
import com.paymitto.android.sdk.AuthenticationResult
import com.paymitto.android.sdk.PayMittoTransferRequest
import com.paymitto.android.sdk.TransferSubmissionResult
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.WritableArray
import com.facebook.react.bridge.WritableMap
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.facebook.react.module.annotations.ReactModule
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import kotlin.coroutines.Continuation
import kotlin.coroutines.resume

@ReactModule(name = PayMittoSdkModule.NAME)
class PayMittoSdkModule(reactContext: ReactApplicationContext) :
  NativePayMittoSdkSpec(reactContext) {

  private var listenerCount: Int = 0

  private val continuationLock = Any()
  private var authContinuation: Continuation<AuthenticationResult>? = null
  private var transferContinuation: Continuation<TransferSubmissionResult>? = null

  companion object {
    const val NAME = "PayMittoSdk"
    private const val AUTH_TIMEOUT_MS = 60_000L
    private const val TRANSFER_TIMEOUT_MS = 120_000L
  }

  override fun getName(): String {
    return NAME
  }

  @ReactMethod
  override fun startSDK(config: ReadableMap?) {
    val readable = config ?: return
    val activity = reactApplicationContext.currentActivity ?: return
    val authenticate: suspend () -> AuthenticationResult = {
      withTimeout(AUTH_TIMEOUT_MS) {
        suspendCancellableCoroutine { cont ->
          synchronized(continuationLock) {
            authContinuation?.resume(
              AuthenticationResult.Error(error = PayMittoError("CANCELLED", "Superseded by new request"))
            )
            authContinuation = cont
          }
          cont.invokeOnCancellation {
            synchronized(continuationLock) { authContinuation = null }
          }
          emitEvent("PAYMITTO_AUTH_TOKEN_REQUESTED", null)
        }
      }
    }
    val submit: suspend (PayMittoTransferRequest) -> TransferSubmissionResult = { request ->
      withTimeout(TRANSFER_TIMEOUT_MS) {
        suspendCancellableCoroutine { cont ->
          synchronized(continuationLock) {
            transferContinuation?.resume(
              TransferSubmissionResult.Error(error = PayMittoError("CANCELLED", "Superseded by new request"))
            )
            transferContinuation = cont
          }
          cont.invokeOnCancellation {
            synchronized(continuationLock) { transferContinuation = null }
          }
          val payload = mapTransferRequestToWritableMap(request)
          emitEvent("PAYMITTO_TRANSFER_SUBMITTED", payload)
        }
      }
    }
    val configuration = ConfigurationConverter.convert(
      readable,
      authenticate = authenticate,
      submit = submit,
      listener = null
    )
    PayMitto.startSdk(
      activity = activity,
      readyRemitConfiguration = configuration
    )
  }

  override fun startTransferDetails(
    config: ReadableMap?,
    transferId: String?
  ) {
    val readable = config ?: return
    val id = transferId ?: return
    val activity = reactApplicationContext.currentActivity ?: return
    val authenticate: suspend () -> AuthenticationResult = {
      withTimeout(AUTH_TIMEOUT_MS) {
        suspendCancellableCoroutine { cont ->
          synchronized(continuationLock) {
            authContinuation?.resume(
              AuthenticationResult.Error(error = PayMittoError("CANCELLED", "Superseded by new request"))
            )
            authContinuation = cont
          }
          cont.invokeOnCancellation {
            synchronized(continuationLock) { authContinuation = null }
          }
          emitEvent("PAYMITTO_AUTH_TOKEN_REQUESTED", null)
        }
      }
    }
    val submit: suspend (PayMittoTransferRequest) -> TransferSubmissionResult = { request ->
      withTimeout(TRANSFER_TIMEOUT_MS) {
        suspendCancellableCoroutine { cont ->
          synchronized(continuationLock) {
            transferContinuation?.resume(
              TransferSubmissionResult.Error(error = PayMittoError("CANCELLED", "Superseded by new request"))
            )
            transferContinuation = cont
          }
          cont.invokeOnCancellation {
            synchronized(continuationLock) { transferContinuation = null }
          }
          val payload = mapTransferRequestToWritableMap(request)
          emitEvent("PAYMITTO_TRANSFER_SUBMITTED", payload)
        }
      }
    }
    val configuration = ConfigurationConverter.convert(
      readable,
      authenticate = authenticate,
      submit = submit,
      listener = null
    )
    PayMitto.openTransferDetailsScreen(
      activity = activity,
      transferId = id,
      readyRemitConfiguration = configuration
    )
  }

  override fun onAccessTokenResponse(
    token: ReadableMap?,
    error: ReadableMap?
  ) {
    val cont = synchronized(continuationLock) {
      val c = authContinuation ?: return
      authContinuation = null
      c
    }
    val accessToken = token?.getString("accessToken")
    val expiresIn = token?.getInt("expiresIn")
    val scope = token?.getString("scope")
    val tokenType = token?.getString("tokenType")

    if (accessToken != null && expiresIn != null && scope != null && tokenType != null) {
      cont.resume(AuthenticationResult.Success(auth = AccessTokenDetails(accessToken, expiresIn, scope, tokenType)))
    } else {
      val code = error?.getString("code") ?: "INVALID_RESPONSE"
      val message = error?.getString("message") ?: "Invalid response format"
      cont.resume(AuthenticationResult.Error(error = PayMittoError(code, message)))
    }
  }

  override fun onTransferResponse(
    response: ReadableMap?,
    error: ReadableMap?
  ) {
    val cont = synchronized(continuationLock) {
      val c = transferContinuation ?: return
      transferContinuation = null
      c
    }
    val transferId = response?.getString("transferId")
    if (transferId != null) {
      cont.resume(TransferSubmissionResult.Success(transferId))
    } else {
      val code = error?.getString("code") ?: "INVALID_TRANSFER_RESPONSE"
      val message = error?.getString("message") ?: "Invalid transfer response format"
      cont.resume(TransferSubmissionResult.Error(error = PayMittoError(code, message)))
    }
  }

  override fun addListener(eventName: String?) {
    // RN will call this when a new JS listener is added for any event.
    // We keep a count and can lazily register native listeners when the first is added.
    listenerCount += 1
    if (listenerCount == 1) {
      // First listener added – hook into native/SDK events here if needed.
      onFirstListenerAdded()
    }
  }

  override fun removeListeners(count: Double) {
    // RN will call this when JS removes listeners; decrement and cleanup when none remain.
    listenerCount -= count.toInt()
    if (listenerCount <= 0) {
      listenerCount = 0
      onNoListenersRemaining()
    }
  }

  /** Called when the first JS listener is added. Register native observers if required. */
  private fun onFirstListenerAdded() {
    // Intentionally left blank for now. When wiring events, register SDK callbacks here.
  }

  /** Called when all JS listeners are removed. Unregister native observers if required. */
  private fun onNoListenersRemaining() {
    // Intentionally left blank for now. When wiring events, unregister SDK callbacks here.
  }

  /** Emits a device event to the JS side. */
  private fun emitEvent(eventName: String, payload: com.facebook.react.bridge.WritableMap?) {
    val emitter = reactApplicationContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
    emitter.emit(eventName, payload)
  }

  /** Convert PayMittoTransferRequest to a WritableMap for JS, mirroring iOS structure. */
  private fun mapTransferRequestToWritableMap(request: PayMittoTransferRequest): WritableMap {
    val map = Arguments.createMap()
    try {
      val quoteBy = request.quoteBy
      val quoteHistoryId = request.quoteHistoryId
      val recipientId = request.recipientId
      val recipientAccountId = request.recipientAccountId
      val sourceAccountId = request.sourceAccountId
      map.putString("quoteBy", quoteBy)
      map.putString("quoteHistoryId", quoteHistoryId)
      map.putString("recipientId", recipientId)
      map.putString("recipientAccountId", recipientAccountId)
      map.putString("sourceAccountId", sourceAccountId)

      val fieldsArray: WritableArray = Arguments.createArray()
      val fields = request.fields
      if (fields != null) {
        for (f in fields) {
          val fMap = Arguments.createMap()
          fMap.putString("id", f.id)
          fMap.putString("value", f.value)
          fMap.putString("type", f.type)
          fieldsArray.pushMap(fMap)
        }
      }
      map.putArray("fields", fieldsArray)
    } catch (_: Throwable) {
      // If any SDK property deviates, still return what we have
    }
    return map
  }
}
