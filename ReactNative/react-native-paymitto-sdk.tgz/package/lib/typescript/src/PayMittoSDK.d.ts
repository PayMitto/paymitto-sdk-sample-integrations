import type { PayMittoError, PayMittoTokenResponse, PayMittoTransferRequest, PayMittoTransferResponse } from "./types/PayMitto.types";
import type { PayMittoConfiguration } from "./types/PayMittoConfiguration.types";
declare class PayMittoSDK {
    private wrapper;
    /**
     * Initializes and starts the PayMitto SDK for money transfer operations.
     *
     * This method sets up the PayMittoSDK flow
     *
     * @param {Object} params - Configuration object for starting the SDK
     * @param {PayMittoConfiguration} params.configuration - SDK configuration including environment, customer credentials, and UI settings
     * @param {Function} params.fetchAccessTokenDetails - Async function to fetch authentication token
     * @param {Function} params.fetchAccessTokenDetails.returns - Promise that resolves to PayMittoTokenResponse on success or PayMittoError on failure
     * @param {Function} params.verifyFundsAndCreateTransfer - Async function to verify funds and create transfer
     * @param {PayMittoTransferRequest} params.verifyFundsAndCreateTransfer.request - Transfer request object containing transfer details
     * @param {Function} params.verifyFundsAndCreateTransfer.returns - Promise that resolves to PayMittoTransferResponse on success or PayMittoError on failure
     * @param {Function} [params.onLoad] - Optional callback executed when SDK is successfully loaded
     * @param {Function} [params.onClose] - Optional callback executed when SDK is closed
     *
     * @example
     * ```typescript
     * const sdk = new PayMittoSDK();
     *
     * sdk.startSDK({
     *   configuration: {
     *     environment: PayMittoEnvironment.SANDBOX,
     *     customerId: 'your-customer-id',
     *     customerSecret: 'your-customer-secret',
     *     senderId: 'your-sender-id'
     *   },
     *   fetchAccessTokenDetails: async () => {
     *     // Your authentication logic
     *     return await authService.getToken();
     *   },
     *   verifyFundsAndCreateTransfer: async (request) => {
     *     // Your transfer processing logic
     *     return await transferService.createTransfer(request);
     *   },
     *   onLoad: async () => {
     *     console.log('SDK loaded successfully');
     *   },
     *   onClose: async () => {
     *     console.log('SDK closed');
     *   }
     * });
     * ```
     *
     * @throws {Error} Throws error if configuration is invalid or SDK initialization fails
     * @since 1.0.0
     */
    startSDK({ configuration, fetchAccessTokenDetails, verifyFundsAndCreateTransfer, onLoad, onClose, }: {
        configuration: PayMittoConfiguration;
        fetchAccessTokenDetails: () => Promise<PayMittoTokenResponse | PayMittoError>;
        verifyFundsAndCreateTransfer: (request: PayMittoTransferRequest) => Promise<PayMittoTransferResponse | PayMittoError>;
        onLoad?: () => Promise<void>;
        onClose?: () => Promise<void>;
    }): void;
    /**
     * Starts the PayMitto SDK in transfer details view mode for a specific transfer.
     *
     * This method initializes the SDK to display details of an existing transfer.
     *
     * @param {Object} params - Configuration object for starting transfer details view
     * @param {string} params.transferId - Unique identifier of the transfer to display details for
     * @param {PayMittoConfiguration} params.configuration - SDK configuration including environment, customer credentials, and UI settings
     * @param {Function} params.fetchAccessTokenDetails - Async function to fetch authentication token
     * @param {Function} params.fetchAccessTokenDetails.returns - Promise that resolves to PayMittoTokenResponse on success or PayMittoError on failure
     * @param {Function} [params.onLoad] - Optional callback executed when SDK transfer details view is successfully loaded
     * @param {Function} [params.onClose] - Optional callback executed when SDK transfer details view is closed
     *
     * @example
     * ```typescript
     * const sdk = new PayMittoSDK();
     *
     * sdk.startTransferDetails({
     *   transferId: 'TXN123456789',
     *   configuration: {
     *     environment: PayMittoEnvironment.SANDBOX,
     *     customerId: 'your-customer-id',
     *     customerSecret: 'your-customer-secret',
     *     senderId: 'your-sender-id'
     *   },
     *   fetchAccessTokenDetails: async () => {
     *     // Your authentication logic
     *     return await authService.getToken();
     *   },
     *   onLoad: async () => {
     *     console.log('Transfer details loaded successfully');
     *   },
     *   onClose: async () => {
     *     console.log('Transfer details view closed');
     *   }
     * });
     * ```
     *
     * @throws {Error} Throws error if transferId is invalid, configuration is invalid, or SDK initialization fails
     * @since 1.0.0
     */
    startTransferDetails({ transferId, configuration, fetchAccessTokenDetails, onLoad, onClose, }: {
        transferId: string;
        configuration: PayMittoConfiguration;
        fetchAccessTokenDetails: () => Promise<PayMittoTokenResponse | PayMittoError>;
        onLoad?: () => Promise<void>;
        onClose?: () => Promise<void>;
    }): void;
    /**
     * Removes all event listeners and cleans up resources
     * Call this method when you're done using the SDK instance
     */
    removeAllListeners(): void;
}
export default PayMittoSDK;
//# sourceMappingURL=PayMittoSDK.d.ts.map