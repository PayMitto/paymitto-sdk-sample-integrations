import type { PayMittoError, PayMittoTokenResponse, PayMittoTransferResponse } from "../types/PayMitto.types";
export declare function isPayMittoError(response: any): response is PayMittoError;
export declare function isPayMittoTokenResponse(response: any): response is PayMittoTokenResponse;
export declare function isPayMittoTransferResponse(response: any): response is PayMittoTransferResponse;
//# sourceMappingURL=TypeValidator.d.ts.map