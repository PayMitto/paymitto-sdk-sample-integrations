import { type TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    startSDK(config: Object): void;
    startTransferDetails(config: Object, transferId: string): void;
    onAccessTokenResponse(token?: Object | null, error?: Object | null): void;
    onTransferResponse(response?: Object | null, error?: Object | null): void;
    addListener(eventName: string): void;
    removeListeners(count: number): void;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativePayMittoSdk.d.ts.map