export { PayMittoEnvironment, PayMittoLocalization, PayMittoRemittanceServiceProvider, PayMittoTransferMethod, } from './types/PayMitto.types';
export type { PayMittoSourceAccount, PayMittoTokenResponse, PayMittoTransferResponse, PayMittoTransferRequestField, PayMittoTransferRequest, PayMittoError, } from './types/PayMitto.types';
export type { PayMittoConfiguration } from './types/PayMittoConfiguration.types';
export { PayMittoSupportedAppearance } from './types/PayMittoAppearance.types';
export type { PayMittoAppearance, PayMittoColorValue, PayMittoFoundations, PayMittoComponents, PayMittoButtonConfig, PayMittoInputFieldsConfig, PayMittoLoadingConfig, PayMittoBackLinkConfig, PayMittoContentConfig, PayMittoFontFamily, PayMittoTextCase, PayMittoBackIconType, PayMittoHomepageHeadline, PayMittoHomepageDescription, } from './types/PayMittoAppearance.types';
export { PayMittoDefaultCountry } from './types/PayMittoDefaultCountry.types';
export declare const startSDK: ({ configuration, fetchAccessTokenDetails, verifyFundsAndCreateTransfer, onLoad, onClose, }: {
    configuration: import(".").PayMittoConfiguration;
    fetchAccessTokenDetails: () => Promise<import(".").PayMittoTokenResponse | import(".").PayMittoError>;
    verifyFundsAndCreateTransfer: (request: import(".").PayMittoTransferRequest) => Promise<import(".").PayMittoTransferResponse | import(".").PayMittoError>;
    onLoad?: () => Promise<void>;
    onClose?: () => Promise<void>;
}) => void;
export declare const startTransferDetails: ({ transferId, configuration, fetchAccessTokenDetails, onLoad, onClose, }: {
    transferId: string;
    configuration: import(".").PayMittoConfiguration;
    fetchAccessTokenDetails: () => Promise<import(".").PayMittoTokenResponse | import(".").PayMittoError>;
    onLoad?: () => Promise<void>;
    onClose?: () => Promise<void>;
}) => void;
//# sourceMappingURL=index.d.ts.map