import type { PayMittoEnvironment, PayMittoLocalization, PayMittoRemittanceServiceProvider, PayMittoSourceAccount, PayMittoTransferMethod } from './PayMitto.types';
import type { PayMittoAppearance } from './PayMittoAppearance.types';
import { PayMittoSupportedAppearance } from './PayMittoAppearance.types';
import type { PayMittoDefaultCountry } from './PayMittoDefaultCountry.types';
export type PayMittoConfiguration = {
    /** The environment where the SDK will operate (production or sandbox) */
    environment: PayMittoEnvironment;
    /**
     * Appearance configuration for customizing the SDK's visual theme.
     * This is a JSON object that will be passed directly to the native SDK.
     * When not provided, the SDK will use its default theme.
     *
     * @example
     * ```typescript
     * appearance: {
     *   foundations: {
     *     colorPrimary: { light: '#007AFF', dark: '#0A84FF' },
     *     fontFamily: 'inter'
     *   },
     *   components: {
     *     button: {
     *       buttonRadius: 8
     *     }
     *   }
     * }
     * ```
     */
    appearance?: PayMittoAppearance | null;
    /**
     * Supported appearance mode for the SDK.
     * Controls whether the SDK uses light theme, dark theme, or follows device settings.
     * Defaults to `device` when not specified.
     */
    supportedAppearance?: PayMittoSupportedAppearance;
    /** Default country to be pre-selected in country selection screens. Set to null for no default */
    defaultCountry?: PayMittoDefaultCountry | null;
    /** Idle timeout interval in seconds. Set to null to disable timeout */
    idleTimeoutInterval?: number | null;
    /** Localization setting for the SDK interface language */
    localization?: PayMittoLocalization;
    /** Preferred remittance service provider. Set to null to allow user selection */
    remittanceServiceProvider?: PayMittoRemittanceServiceProvider | null;
    /** Array of available source accounts for transfers. Set to null to fetch dynamically */
    sourceAccounts?: PayMittoSourceAccount[] | null;
    /** Preferred transfer method. Set to null to allow user selection */
    transferMethod?: PayMittoTransferMethod | null;
};
//# sourceMappingURL=PayMittoConfiguration.types.d.ts.map