/**
 * Color value for light and dark appearances
 *
 * @example
 * ```typescript
 * const color: PayMittoColorValue = {
 *   light: '#007AFF',
 *   dark: '#0A84FF'
 * };
 * ```
 */
export type PayMittoColorValue = {
    /** Hex color for light mode (e.g., '#FFFFFF') */
    light: string;
    /** Hex color for dark mode (e.g., '#000000') */
    dark: string;
};
/**
 * Font family options supported by the SDK
 */
export type PayMittoFontFamily = 'inter' | 'roboto' | 'source sans 3' | 'sf pro';
/**
 * Text case transformation options
 */
export type PayMittoTextCase = 'none' | 'capitalize' | 'uppercase' | 'lowercase';
/**
 * Back icon type options
 */
export type PayMittoBackIconType = 'arrow' | 'chevron';
/**
 * Homepage headline options
 */
export type PayMittoHomepageHeadline = 'Global transfer' | 'International & domestic transfers' | 'International transfers' | 'Send money internationally';
/**
 * Homepage description options
 */
export type PayMittoHomepageDescription = 'Send funds to your recipients with convenience and flexibility.' | 'Send money to friends and family in other countries';
/**
 * Foundation colors configuration
 *
 * Contains the core color tokens used throughout the SDK
 */
export type PayMittoFoundations = {
    /** Primary brand color */
    colorPrimary?: PayMittoColorValue;
    /** Primary text color */
    colorTextPrimary?: PayMittoColorValue;
    /** Secondary text color */
    colorTextSecondary?: PayMittoColorValue;
    /** Link text color */
    colorTextLink?: PayMittoColorValue;
    /** Foreground/surface color */
    colorForeground?: PayMittoColorValue;
    /** Background color */
    colorBackground?: PayMittoColorValue;
    /** Divider/separator color */
    colorDivider?: PayMittoColorValue;
    /** Success state color */
    colorSuccess?: PayMittoColorValue;
    /** Warning state color */
    colorWarning?: PayMittoColorValue;
    /** Danger/error state color */
    colorDanger?: PayMittoColorValue;
    /** Font family to use throughout the SDK */
    fontFamily?: PayMittoFontFamily;
};
/**
 * Button component configuration
 */
export type PayMittoButtonConfig = {
    /** Primary button background color */
    buttonPrimaryBackgroundColor?: PayMittoColorValue;
    /** Primary button text color */
    buttonPrimaryTextColor?: PayMittoColorValue;
    /** Secondary button border color */
    buttonSecondaryBorderColor?: PayMittoColorValue;
    /** Secondary button text color */
    buttonSecondaryTextColor?: PayMittoColorValue;
    /** Text case transformation for button labels */
    buttonTextCase?: PayMittoTextCase;
    /** Whether to show text shadow on primary buttons */
    buttonPrimaryTextShadow?: boolean;
    /** Button corner radius in dp/pt */
    buttonRadius?: number;
};
/**
 * Input field component configuration
 */
export type PayMittoInputFieldsConfig = {
    /** Input field border color */
    inputBorderColor?: PayMittoColorValue;
    /** Input field background color */
    inputBackgroundColor?: PayMittoColorValue;
    /** Input field corner radius in dp/pt */
    inputRadius?: number;
};
/**
 * Loading screen configuration
 */
export type PayMittoLoadingConfig = {
    /** Loading screen background color */
    loadingBackgroundColor?: PayMittoColorValue;
    /** Loading screen text color */
    loadingTextColor?: PayMittoColorValue;
    /** Loading spinner color */
    loadingSpinnerColor?: PayMittoColorValue;
};
/**
 * Back link/navigation configuration
 */
export type PayMittoBackLinkConfig = {
    /** Back button icon type */
    backIconType?: PayMittoBackIconType;
    /** Text case for back button label */
    backTextCase?: PayMittoTextCase;
};
/**
 * Content/copy configuration for the home screen
 */
export type PayMittoContentConfig = {
    /** Homepage headline text */
    contentHomepageHeadline?: PayMittoHomepageHeadline;
    /** Homepage description text */
    contentHomepageDescription?: PayMittoHomepageDescription;
};
/**
 * Components configuration
 *
 * Contains configuration for individual UI components
 */
export type PayMittoComponents = {
    /** Button styling configuration */
    button?: PayMittoButtonConfig;
    /** Input field styling configuration */
    inputFields?: PayMittoInputFieldsConfig;
    /** Loading screen configuration */
    loading?: PayMittoLoadingConfig;
    /** Back navigation configuration */
    backLink?: PayMittoBackLinkConfig;
    /** Content/copy configuration */
    content?: PayMittoContentConfig;
};
/**
 * Complete appearance configuration for the PayMitto SDK
 *
 * This object will be serialized to JSON and passed to the native SDK.
 * It follows the same structure as the SDK's internal configuration format.
 *
 * @example
 * ```typescript
 * const appearance: PayMittoAppearance = {
 *   foundations: {
 *     colorPrimary: { light: '#007AFF', dark: '#0A84FF' },
 *     colorBackground: { light: '#FFFFFF', dark: '#000000' },
 *     fontFamily: 'inter'
 *   },
 *   components: {
 *     button: {
 *       buttonPrimaryBackgroundColor: { light: '#007AFF', dark: '#0A84FF' },
 *       buttonRadius: 8
 *     }
 *   }
 * };
 * ```
 */
export type PayMittoAppearance = {
    /** Foundation/base design tokens */
    foundations?: PayMittoFoundations;
    /** Component-specific configurations */
    components?: PayMittoComponents;
};
/**
 * Supported appearance modes for the SDK
 *
 * - `light`: SDK will always use light theme
 * - `dark`: SDK will always use dark theme
 * - `device`: SDK will follow device/system appearance setting
 */
export declare enum PayMittoSupportedAppearance {
    /** Only light appearance is supported */
    Light = "light",
    /** Only dark appearance is supported */
    Dark = "dark",
    /** Both light and dark appearances are supported, follows device setting */
    Device = "device"
}
//# sourceMappingURL=PayMittoAppearance.types.d.ts.map