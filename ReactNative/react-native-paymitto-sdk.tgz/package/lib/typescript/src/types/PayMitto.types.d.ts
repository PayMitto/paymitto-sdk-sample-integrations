export declare enum PayMittoRemittanceServiceProvider {
    CONVERA = "convera",
    MASTERCARD = "mastercard",
    MONEY_GRAM = "moneyGram",
    VISA = "visa"
}
export declare enum PayMittoEnvironment {
    Production = "PRODUCTION",
    Sandbox = "SANDBOX"
}
export declare enum PayMittoLocalization {
    EN_US = "en-US",
    ES_MX = "es-MX"
}
export declare enum PayMittoTransferMethod {
    BANK_ACCOUNT = "bankAccount",
    CASH_PICKUP = "cashPickup",
    MOBILE_WALLET = "mobileWallet",
    PUSH_TO_CARD = "pushToCard"
}
export type PayMittoSourceAccount = {
    alias: string;
    balance: number;
    last4: string;
    sourceProviderId: string;
};
/**
 * Response interface for authentication token requests
 *
 * This interface represents the expected structure of a successful token response
 * that should be provided to the SDK when handling TOKEN_REQUESTED events.
 *
 * @public
 */
export interface PayMittoTokenResponse {
    accessToken: string;
    expiresIn: number;
    scope: string;
    tokenType: string;
}
/**
 * Response interface for successful transfer submissions
 *
 * This interface represents the structure of a successful transfer response
 * returned after a transfer has been processed.
 *
 * @public
 */
export interface PayMittoTransferResponse {
    transferId: string;
}
/**
 * Error interface for SDK operations
 *
 * This interface represents the structure of error responses that can occur
 * during SDK operations such as authentication or transfer processing.
 *
 * @public
 */
export interface PayMittoError {
    code: string;
    message: string;
}
/**
 * Request interface for transfer submission
 *
 * This interface defines the structure of transfer requests that will be sent
 * by the SDK.
 *
 *
 * @public
 */
export type PayMittoTransferRequest = {
    fields?: [PayMittoTransferRequestField] | undefined;
    quoteBy: string;
    quoteHistoryId: string;
    recipientAccountId?: string | undefined;
    recipientId: string;
    sourceAccountId?: string | undefined;
};
export type PayMittoTransferRequestField = {
    id: string;
    type: string;
    value: string;
};
//# sourceMappingURL=PayMitto.types.d.ts.map