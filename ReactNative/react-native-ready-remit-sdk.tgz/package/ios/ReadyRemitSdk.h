#import <ReadyRemitSdkSpec/ReadyRemitSdkSpec.h>
#import <React/RCTEventEmitter.h>

@interface ReadyRemitSdk : RCTEventEmitter <NativeReadyRemitSdkSpec>

@end
