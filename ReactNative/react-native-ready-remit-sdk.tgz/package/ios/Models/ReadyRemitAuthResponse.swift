//
//  ReadyRemitAuthResponse.swift
//  Pods
//
//  Created by Lucas Bordini on 11/7/25.
//

import ReadyRemitSDK

struct ReadyRemitAuthResponse: ReadyRemitSDK.AccessTokenDetails {
  let accessToken: String
  let expiresIn: Int
  let scope: String
  let tokenType: String
}
