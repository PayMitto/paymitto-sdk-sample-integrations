//
//  ReadyRemitSdkImpl.swift
//  ReadyRemitSdk
//
//  Created by Lucas Bordini on 11/6/25.
//

import Foundation
import UIKit
import ReadyRemitSDK

@objc(ReadyRemitSdkImpl)
public class ReadyRemitSdkImpl: NSObject, @unchecked Sendable {
    
    private let continuationQueue = DispatchQueue(label: "com.brightwell.readyremitsdk.continuation", attributes: .concurrent)
    private var authContinuation: CheckedContinuation<ReadyRemitAuthResponse, Error>?
    private var transferContinuation: CheckedContinuation<ReadyRemitTransferResponse, Error>?
    private var authTimeoutTask: Task<Void, Never>?
    private var transferTimeoutTask: Task<Void, Never>?
    private let configurationConverter = ConfigurationConverter()
    
    @objc(startSDK:)
    public func startSDK(_ config: NSDictionary) {
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            let dataConfig = config as? [String: Any] ?? [:]
            
            let sdkConfig = configurationConverter.convert(dataConfig)
            let themeConfig = configurationConverter.extractAppearanceJSON(dataConfig)
            
            let viewController = createViewController(
                config: sdkConfig,
                themeConfiguration: themeConfig
            )
            viewController.startSDK()
            
            let navigationController = UINavigationController(rootViewController: viewController)
            navigationController.modalPresentationStyle = .overCurrentContext
            
            guard let window = UIApplication.shared.delegate?.window as? UIWindow,
                  let rootVC = window.rootViewController else { return }
            rootVC.present(navigationController, animated: true)
        }
    }
    
    @objc(startTransferDetails:transferId:)
    public func startTransferDetails(_ config: NSDictionary, transferId: String) {
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            let dataConfig = config as? [String: Any] ?? [:]
            
            let sdkConfig = configurationConverter.convert(dataConfig)
            let themeConfig = configurationConverter.extractAppearanceJSON(dataConfig)
            
            let viewController = createViewController(
                config: sdkConfig,
                themeConfiguration: themeConfig
            )
            viewController.startTransferDetails(transferId: transferId)
            
            let navigationController = UINavigationController(rootViewController: viewController)
            navigationController.modalPresentationStyle = .overCurrentContext
            
            guard let window = UIApplication.shared.delegate?.window as? UIWindow,
                  let rootVC = window.rootViewController else { return }
            rootVC.present(navigationController, animated: true)
        }
    }
    
    @objc(onAccessTokenResponse:error:)
    public func onAccessTokenResponse(_ token: NSDictionary?, error: NSDictionary?) {
        continuationQueue.async(flags: .barrier) { [weak self] in
            guard let self, let continuation = self.authContinuation else { return }
            
            // Cancel timeout task
            self.authTimeoutTask?.cancel()
            self.authTimeoutTask = nil
            
            if let token,
               let accessToken = token["accessToken"] as? String,
               let expiresIn = token["expiresIn"] as? Int,
               let scope = token["scope"] as? String,
               let tokenType = token["tokenType"] as? String {
                continuation.resume(returning: ReadyRemitAuthResponse(
                    accessToken: accessToken,
                    expiresIn: expiresIn,
                    scope: scope,
                    tokenType: tokenType
                ))
            } else if let error,
                      let code = error["code"] as? String,
                      let message = error["message"] as? String {
                continuation.resume(throwing: ReadyRemitError(code: code, message: message))
            } else {
                let errorMessage = error?["message"] as? String ?? "Invalid response format"
                continuation.resume(throwing: ReadyRemitError(code: "INVALID_RESPONSE", message: errorMessage))
            }
            
            self.authContinuation = nil
        }
    }
    
    @objc(onTransferResponse:error:)
    public func onTransferResponse(_ response: NSDictionary?, error: NSDictionary?) {
        continuationQueue.async(flags: .barrier) { [weak self] in
            guard let self, let continuation = self.transferContinuation else { return }
            
            // Cancel timeout task
            self.transferTimeoutTask?.cancel()
            self.transferTimeoutTask = nil
            
            if let response, let transferId = response["transferId"] as? String {
                continuation.resume(returning: ReadyRemitTransferResponse(transferId: transferId))
            } else if let error,
                      let code = error["code"] as? String,
                      let message = error["message"] as? String {
                continuation.resume(throwing: ReadyRemitError(code: code, message: message))
            } else {
                let errorMessage = error?["message"] as? String ?? "Invalid transfer response format"
                continuation.resume(throwing: ReadyRemitError(code: "INVALID_TRANSFER_RESPONSE", message: errorMessage))
            }
            
            self.transferContinuation = nil
        }
    }
    
    // MARK: Private and helper functions
    nonisolated private static let genericError = ReadyRemitError(code: nil, message: "Something went wrong")
    
    private func createViewController(
        config: ReadyRemitSDK.ReadyRemitConfiguration,
        themeConfiguration: String?
    ) -> ReadyRemitViewController {
        let viewController = ReadyRemitViewController(
            configuration: config,
            themeConfiguration: themeConfiguration,
            fetchAccessTokenDetails: { [weak self] in
                guard let self else { throw Self.genericError }
                return try await onRequestTokenFromJS()
            },
            verifyFundsAndCreateTransfer: { [weak self] (transferRequest: ReadyRemitSDK.TransferRequest) throws(ReadyRemitSDK.ReadyRemitError) -> ReadyRemitTransferResponse  in
                    guard let self else { throw Self.genericError }
                    return try await onRequestTransferFromJS(request: transferRequest)
                  },
            onLaunch: { [weak self] in
                guard let self else { return }
                NotificationCenter.default.post(name: Notification.Name("READYREMIT_SDK_LAUNCHED"), object: nil, userInfo: [:])
            },
            onDismiss: { [weak self] in
                guard let self else { return }
                NotificationCenter.default.post(name: Notification.Name("READYREMIT_SDK_CLOSED"), object: nil, userInfo: [:])
            }
        )
        viewController.modalPresentationStyle = .overCurrentContext
        return viewController
    }
    
    private func onRequestTokenFromJS() async throws -> ReadyRemitAuthResponse {
        return try await withCheckedThrowingContinuation { [weak self] continuation in
            guard let self else {
                continuation.resume(throwing: ReadyRemitSDK.ReadyRemitError(code: "MODULE_DEALLOCATED", message: "ReadyRemit module was deallocated"))
                return
            }
            
            continuationQueue.async(flags: .barrier) { [weak self] in
                guard let self else { return }
                self.authContinuation = continuation
                
                // Set up timeout task
                self.authTimeoutTask = Task { [weak self] in
                    try? await Task.sleep(for: .seconds(60))
                    
                    guard let self else { return }
                    
                    self.continuationQueue.async(flags: .barrier) { [weak self] in
                        guard let self, let continuation = self.authContinuation else { return }
                        continuation.resume(throwing: ReadyRemitSDK.ReadyRemitError(code: "TIMEOUT", message: "Authentication request timed out"))
                        self.authContinuation = nil
                    }
                }
            }
            
            NotificationCenter.default.post(name: Notification.Name("READYREMIT_AUTH_TOKEN_REQUESTED"), object: nil, userInfo: [:])
        }
    }
    
    private func onRequestTransferFromJS(request: ReadyRemitSDK.TransferRequest) async throws(ReadyRemitSDK.ReadyRemitError) -> ReadyRemitTransferResponse {
        return try await capturing(ReadyRemitSDK.ReadyRemitError.self) {
            try await withCheckedThrowingContinuation { [weak self] continuation in
                guard let self else {
                    continuation.resume(throwing: ReadyRemitSDK.ReadyRemitError(code: "MODULE_DEALLOCATED", message: "ReadyRemit module was deallocated"))
                    return
                }
                
                continuationQueue.async(flags: .barrier) { [weak self] in
                    guard let self else { return }
                    self.transferContinuation = continuation
                    
                    // Set up timeout task
                    self.transferTimeoutTask = Task { [weak self] in
                        try? await Task.sleep(for: .seconds(120))
                        
                        guard let self else { return }
                        
                        self.continuationQueue.async(flags: .barrier) { [weak self] in
                            guard let self, let continuation = self.transferContinuation else { return }
                            continuation.resume(throwing: ReadyRemitSDK.ReadyRemitError(code: "TIMEOUT", message: "Transfer request timed out"))
                            self.transferContinuation = nil
                        }
                    }
                }
                NotificationCenter.default.post(name: Notification.Name("READYREMIT_TRANSFER_SUBMITTED"), object: nil, userInfo: request.toDictionary())
            }
        }
    }
    
    private func capturing<Success, Failure: Swift.Error>(
        _: Failure.Type,
        _ body: () async throws -> Success
    ) async throws(Failure) -> Success {
        do {
            return try await body()
        } catch let error as Failure {
            throw error
        } catch {
            throw ReadyRemitError(code: "UNEXPECTED_ERROR", message: error.localizedDescription) as! Failure
        }
    }
    
    // MARK: - Cleanup
    private func cleanup() {
        continuationQueue.async(flags: .barrier) { [weak self] in
            guard let self else { return }
            
            // Cancel any pending timeout tasks
            self.authTimeoutTask?.cancel()
            self.transferTimeoutTask?.cancel()
            self.authTimeoutTask = nil
            self.transferTimeoutTask = nil
            
            // Resume any pending continuations with cancellation errors
            if let authContinuation = self.authContinuation {
                authContinuation.resume(throwing: ReadyRemitError(code: "CANCELLED", message: "Operation was cancelled"))
                self.authContinuation = nil
            }
            
            if let transferContinuation = self.transferContinuation {
                transferContinuation.resume(throwing: ReadyRemitError(code: "CANCELLED", message: "Operation was cancelled"))
                self.transferContinuation = nil
            }
        }
    }
    
}
