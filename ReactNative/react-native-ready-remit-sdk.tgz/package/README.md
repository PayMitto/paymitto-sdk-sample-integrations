# ReadyRemit SDK - React Native Wrapper

A React Native wrapper for the ReadyRemit SDK, enabling seamless integration of international money transfer capabilities into React Native applications.

## Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Project Structure](#project-structure)
- [Requirements](#requirements)
- [Installation](#installation)
- [Development Guide](#development-guide)
- [iOS Implementation Details](#ios-implementation-details)
- [Android Implementation Details](#android-implementation-details)
- [TypeScript API](#typescript-api)
- [Example App](#example-app)
- [Building & Publishing](#building--publishing)
- [Troubleshooting](#troubleshooting)

---

## Overview

This package provides a React Native wrapper around the native ReadyRemit SDKs for iOS and Android. It uses React Native's **TurboModules** (New Architecture) to bridge JavaScript and native code, providing type-safe communication between the layers.

### Key Features

- Full TypeScript support with comprehensive type definitions
- TurboModule-based architecture for optimal performance
- Support for both standard SDK flow and transfer details view
- Customizable theming via JSON configuration
- Expo config plugin for easy Expo integration
- Event-driven communication between JS and native layers

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        React Native App                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────────┐    ┌──────────────────────────────────┐  │
│  │  ReadyRemitSDK   │───▶│  ReadyRemitModuleWrapper         │  │
│  │  (TypeScript)    │    │  (Event handling & JS bridge)    │  │
│  └──────────────────┘    └──────────────────────────────────┘  │
│                                     │                            │
│                                     ▼                            │
│                          ┌──────────────────────┐               │
│                          │  NativeReadyRemitSdk │               │
│                          │  (TurboModule Spec)  │               │
│                          └──────────────────────┘               │
│                                     │                            │
├─────────────────────────────────────┼────────────────────────────┤
│                    Native Bridge    │                            │
├─────────────────────────────────────┼────────────────────────────┤
│                                     │                            │
│  ┌──────────────────────────────────┴───────────────────────┐   │
│  │                                                           │   │
│  │  ┌─────────────────┐           ┌─────────────────────┐   │   │
│  │  │  iOS Module     │           │  Android Module     │   │   │
│  │  │  (Obj-C + Swift)│           │  (Kotlin)           │   │   │
│  │  └────────┬────────┘           └──────────┬──────────┘   │   │
│  │           │                               │               │   │
│  │           ▼                               ▼               │   │
│  │  ┌─────────────────┐           ┌─────────────────────┐   │   │
│  │  │ ReadyRemitSDK   │           │ ReadyRemitSDK       │   │   │
│  │  │ (XCFramework)   │           │ (Maven/AAR)         │   │   │
│  │  └─────────────────┘           └─────────────────────┘   │   │
│  │                                                           │   │
│  └───────────────────────────────────────────────────────────┘   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Communication Flow

1. **JS → Native**: Method calls via TurboModule (`startSDK`, `startTransferDetails`)
2. **Native → JS**: Events via `NativeEventEmitter` (`TOKEN_REQUESTED`, `TRANSFER_SUBMITTED`, etc.)
3. **JS → Native (Response)**: Callback methods (`onAccessTokenResponse`, `onTransferResponse`)

---

## Project Structure

```
SDK-ReactNative-Wrapper/
├── src/                          # TypeScript source code
│   ├── index.tsx                 # Main exports
│   ├── NativeReadyRemitSdk.ts    # TurboModule spec definition
│   ├── ReadyRemitSDK.ts          # High-level SDK class
│   ├── types/                    # TypeScript type definitions
│   │   ├── ReadyRemit.types.ts
│   │   ├── ReadyRemitAppearance.types.ts
│   │   ├── ReadyRemitConfiguration.types.ts
│   │   └── ReadyRemitDefaultCountry.types.ts
│   └── utils/
│       ├── ReadyRemitSDKWrapper.ts  # Native module wrapper
│       └── TypeValidator.ts         # Runtime type guards
│
├── ios/                          # iOS native code
│   ├── ReadyRemitSdk.h           # Obj-C header (TurboModule interface)
│   ├── ReadyRemitSdk.mm          # Obj-C++ implementation (bridge)
│   ├── ReadyRemitSdkImpl.swift   # Swift implementation (business logic)
│   ├── Frameworks/               # Vendored XCFrameworks
│   │   ├── ReadyRemitSDK.xcframework
│   │   └── VisaSensoryBranding.xcframework
│   ├── Models/                   # Response models
│   │   ├── ReadyRemitAuthResponse.swift
│   │   └── ReadyRemitTransferResponse.swift
│   ├── Utils/
│   │   ├── ConfigurationConverter.swift  # JS config → Swift config
│   │   └── ReadyRemit+ReactNative.swift  # SDK extensions
│   └── ViewControllers/
│       └── ReadyRemitViewController.swift
│
├── android/                      # Android native code
│   ├── build.gradle              # Gradle build config
│   ├── gradle.properties         # Gradle properties
│   ├── libs/                     # Vendored AAR files
│   │   └── visa-sensory-branding-2.0.aar
│   └── src/main/java/com/readyremitsdk/
│       ├── ConfigurationConverter.kt  # JS config → Kotlin config
│       ├── ReadyRemitSdkModule.kt     # TurboModule implementation
│       └── ReadyRemitSdkPackage.kt    # Package registration
│
├── example/                      # Example React Native app
│   ├── src/App.tsx               # Example implementation
│   ├── android/                  # Android example project
│   └── ios/                      # iOS example project
│
├── plugin/                       # Expo config plugin
│   └── with-readyremit-sdk.js    # Auto-configures Expo projects
│
│
├── package.json                  # NPM package configuration
├── ReadyRemitSdk.podspec         # CocoaPods spec
├── tsconfig.json                 # TypeScript configuration
└── turbo.json                    # Turborepo configuration
```

---

## Requirements

### Minimum Versions

| Platform              | Version           |
|-----------------------|-------------------|
| React Native          | 0.75.x            |
| iOS                   | 16.0              |
| Android Min SDK       | 26                |
| Android Target SDK    | 36                |
| Kotlin                | 2.1.20            |
| Android Gradle Plugin | 8.11.x            |
| JDK                   | 17                |
| Xcode                 | 16.0              |
| Swift                 | 5                 |

### New Architecture Required

This SDK uses **TurboModules** which requires React Native's New Architecture to be enabled. Without enabling the New Architecture, you will see errors like:

```
TurboModuleRegistry.getEnforcing(...): 'ReadyRemitSdk' could not be found
```

#### Enabling New Architecture on iOS

Add the following line at the **top** of your `ios/Podfile`:

```ruby
# Enable New Architecture (required for ReadyRemit SDK TurboModules)
ENV['RCT_NEW_ARCH_ENABLED'] = '1'
```

Then reinstall pods:

```bash
cd ios
rm -rf Pods Podfile.lock
pod install
```

#### Enabling New Architecture on Android

Update `android/gradle.properties`:

```properties
newArchEnabled=true
```

Then clean and rebuild:

```bash
cd android
./gradlew clean
```

---

## Installation

### For Expo Projects

```bash
# Install the package
yarn add react-native-ready-remit-sdk

# Install build properties plugin
yarn add expo-build-properties
```

Add to `app.json`:

```json
{
  "expo": {
    "plugins": [
      "react-native-ready-remit-sdk/plugin/with-readyremit-sdk",
      ["expo-build-properties", {
        "ios": { "deploymentTarget": "16.0" },
        "android": {
          "compileSdkVersion": 36,
          "targetSdkVersion": 36,
          "minSdkVersion": 26,
          "kotlinVersion": "2.1.20",
          "gradlePluginVersion": "8.11.0"
        }
      }]
    ]
  }
}
```

Then run:

```bash
npx expo prebuild --clean
cd ios && pod install
```

### For Bare React Native Projects

```bash
# Install from tarball
yarn add file:./react-native-ready-remit-sdk-10.0.0.tgz

# iOS: Install pods
cd ios && pod install
```

---

## Development Guide

### Initial Setup

```bash
# Clone the repository
git clone <repository-url>
cd SDK-ReactNative-Wrapper

# Install dependencies
yarn install

# Build TypeScript
yarn prepare
```

### Running the Example App

#### iOS

```bash
# Install pods (first time or after native dependency changes)
cd example/ios
bundle install          # Install Ruby dependencies (first time only)
bundle exec pod install
cd ../..

# Run the app
yarn example ios
```

#### Android

```bash
# Run the app
yarn example android
```

### Making Changes

1. **TypeScript changes** (`src/`):
   ```bash
   # Rebuild TypeScript after changes
   yarn prepare
   
   # Then restart Metro bundler in example
   cd example && yarn start --reset-cache
   ```

2. **iOS native changes** (`ios/`):
   ```bash
   # Reinstall pods if you added new dependencies
   cd example/ios && pod install
   
   # Then rebuild the app
   yarn example ios
   ```

3. **Android native changes** (`android/`):
   ```bash
   # Clean and rebuild
   cd example/android && ./gradlew clean
   yarn example android
   ```

### Updating Native SDKs

#### iOS SDK

1. Replace the XCFramework in `ios/Frameworks/ReadyRemitSDK.xcframework`
2. Run `pod install` in the example project

#### Android SDK

The Android SDK is fetched from Maven. To use a local version:

1. Publish to Maven Local from SDK-Android:
   ```bash
   cd ../SDK-Android
   ./gradlew :sdk:publishToMavenLocal
   ```

2. Clear Gradle cache in the wrapper:
   ```bash
   rm -rf ~/.gradle/caches/modules-2/files-2.1/io.github.brightwellpayments
   cd example/android && ./gradlew clean --refresh-dependencies
   ```

---

## iOS Implementation Details

### The Objective-C/Swift Bridge Challenge

React Native's TurboModules require Objective-C++ (`.mm`) files to interface with the JavaScript bridge. However, our SDK implementation is in Swift. This creates a challenge because:

1. TurboModule spec generates Objective-C++ code that expects Objective-C method implementations
2. Swift classes cannot directly conform to Objective-C++ protocols
3. Direct Swift-to-Objective-C++ bridging has limitations

### The Reflection Solution

We solved this using **runtime reflection** (`objc_msgSend`) in the Objective-C++ layer:

```objc
// ReadyRemitSdk.mm

@implementation ReadyRemitSdk
{
  id moduleImpl;  // Holds reference to Swift implementation
}

- (instancetype)init
{
  self = [super init];
  if (self) {
    // Dynamically load the Swift implementation class at runtime
    Class implClass = NSClassFromString(@"ReadyRemitSdkImpl");
    if (implClass != Nil) {
      moduleImpl = [implClass new];
    }
  }
  return self;
}

// Bridge methods use objc_msgSend for dynamic dispatch to Swift
- (void)startSDK:(nonnull NSDictionary *)config { 
  SEL sel = NSSelectorFromString(@"startSDK:");
  if (moduleImpl && [moduleImpl respondsToSelector:sel]) {
    ((void(*)(id, SEL, NSDictionary *))objc_msgSend)(moduleImpl, sel, config);
  }
}
```

### Why This Approach?

1. **Separation of Concerns**: The `.mm` file handles only the TurboModule interface; all business logic lives in Swift (`ReadyRemitSdkImpl.swift`)

2. **Type Safety**: The Swift implementation can use proper Swift types and the ReadyRemitSDK framework directly

3. **Maintainability**: Changes to SDK logic only require Swift changes, not Objective-C++

4. **Runtime Flexibility**: `NSClassFromString` allows the Swift class to be loaded dynamically, avoiding compile-time circular dependencies

### Event Communication

Events flow from Swift → Objective-C → JavaScript via `NotificationCenter`:

```swift
// ReadyRemitSdkImpl.swift
NotificationCenter.default.post(
  name: Notification.Name("READYREMIT_AUTH_TOKEN_REQUESTED"),
  object: nil,
  userInfo: [:]
)
```

```objc
// ReadyRemitSdk.mm
- (void)startObserving {
  [[NSNotificationCenter defaultCenter] addObserver:self
    selector:@selector(handleEventNotification:)
    name:@"READYREMIT_AUTH_TOKEN_REQUESTED"
    object:nil];
}

- (void)handleEventNotification:(NSNotification *)notification {
  [self sendEventWithName:notification.name body:notification.userInfo];
}
```

### File Responsibilities

| File | Purpose |
|------|---------|
| `ReadyRemitSdk.h` | TurboModule protocol conformance declaration |
| `ReadyRemitSdk.mm` | Objective-C++ bridge with reflection to Swift |
| `ReadyRemitSdkImpl.swift` | All business logic, async handling, SDK invocation |
| `ConfigurationConverter.swift` | Converts JS config dictionaries to Swift SDK types |
| `ReadyRemitViewController.swift` | UIViewController wrapper for SDK presentation |

---

## Android Implementation Details

### Module Structure

The Android implementation uses Kotlin and follows the standard TurboModule pattern:

```kotlin
// ReadyRemitSdkModule.kt
@ReactModule(name = ReadyRemitSdkModule.NAME)
class ReadyRemitSdkModule(reactContext: ReactApplicationContext) :
  NativeReadyRemitSdkSpec(reactContext) {
  
  // Continuations for bridging suspend functions with JS callbacks
  @Volatile private var authContinuation: Continuation<AuthenticationResult>? = null
  @Volatile private var transferContinuation: Continuation<TransferSubmissionResult>? = null
  
  override fun startSDK(config: ReadableMap?) {
    val configuration = ConfigurationConverter.convert(
      readable,
      authenticate = { /* suspend coroutine until JS responds */ },
      submit = { /* suspend coroutine until JS responds */ }
    )
    ReadyRemit.startSdk(activity, configuration)
  }
}
```

### Coroutine-based Communication

The Android SDK uses Kotlin coroutines for async operations. We bridge this with JS using `suspendCoroutine`:

```kotlin
val authenticate: suspend () -> AuthenticationResult = {
  suspendCoroutine { cont ->
    authContinuation = cont
    emitEvent("READYREMIT_AUTH_TOKEN_REQUESTED", null)
    // Coroutine suspends here until onAccessTokenResponse is called
  }
}

override fun onAccessTokenResponse(token: ReadableMap?, error: ReadableMap?) {
  val cont = authContinuation ?: return
  authContinuation = null
  
  if (token != null) {
    cont.resume(AuthenticationResult.Success(/* ... */))
  } else {
    cont.resume(AuthenticationResult.Error(/* ... */))
  }
}
```

### Configuration Conversion

```kotlin
// ConfigurationConverter.kt
object ConfigurationConverter {
  fun convert(config: Map<String, Any?>, ...): ReadyRemitConfiguration {
    val appearance = extractAppearanceJSON(config)  // Convert to JSON string
    val defaultCountry = convertDefaultCountry(config["defaultCountry"])
    val environment = convertEnvironment(config["environment"])
    // ... more conversions
    
    return ReadyRemitConfiguration(
      appearance = appearance,
      environment = environment,
      // ...
    )
  }
}
```

---

## TypeScript API

### Basic Usage

```typescript
import {
  startSDK,
  ReadyRemitEnvironment,
  ReadyRemitSupportedAppearance,
  type ReadyRemitAppearance,
} from 'react-native-ready-remit-sdk';

const appearance: ReadyRemitAppearance = {
  foundations: {
    colorPrimary: { light: '#007AFF', dark: '#0A84FF' },
    fontFamily: 'inter',
  },
  components: {
    button: { buttonRadius: 8 },
  },
};

startSDK({
  configuration: {
    environment: ReadyRemitEnvironment.Sandbox,
    appearance,
    supportedAppearance: ReadyRemitSupportedAppearance.Device,
  },
  fetchAccessTokenDetails: async () => ({
    accessToken: 'your-token',
    expiresIn: 3600,
    scope: 'readyremit:write',
    tokenType: 'Bearer',
  }),
  verifyFundsAndCreateTransfer: async (request) => ({
    transferId: 'TXN123',
  }),
  onLoad: async () => console.log('SDK loaded'),
  onClose: async () => console.log('SDK closed'),
});
```

### Exported Types

```typescript
// Configuration
export type { ReadyRemitConfiguration } from './types/ReadyRemitConfiguration.types';

// Appearance (theming)
export type {
  ReadyRemitAppearance,
  ReadyRemitColorValue,
  ReadyRemitFoundations,
  ReadyRemitComponents,
  ReadyRemitButtonConfig,
  ReadyRemitInputFieldsConfig,
  ReadyRemitLoadingConfig,
  ReadyRemitBackLinkConfig,
  ReadyRemitContentConfig,
} from './types/ReadyRemitAppearance.types';

// Enums
export {
  ReadyRemitEnvironment,
  ReadyRemitLocalization,
  ReadyRemitRemittanceServiceProvider,
  ReadyRemitTransferMethod,
  ReadyRemitSupportedAppearance,
  ReadyRemitDefaultCountry,
} from './types';

// Request/Response types
export type {
  ReadyRemitSourceAccount,
  ReadyRemitTokenResponse,
  ReadyRemitTransferResponse,
  ReadyRemitTransferRequest,
  ReadyRemitError,
} from './types/ReadyRemit.types';
```

---

## Example App

The `example/` directory contains a fully functional React Native app demonstrating SDK integration.

### Running the Example

```bash
# From repository root
cd SDK-ReactNative-Wrapper

# Install all dependencies
yarn install

# Build TypeScript
yarn prepare

# Run iOS
cd example/ios && pod install && cd ../..
yarn example ios

# Run Android
yarn example android
```

### Example Structure

```
example/
├── src/
│   └── App.tsx          # Main app with full SDK configuration example
├── android/             # Android project files
│   ├── app/
│   │   └── build.gradle # App-level Gradle config with Compose setup
│   ├── build.gradle     # Project-level Gradle config
│   └── gradle.properties
└── ios/                 # iOS project files
    ├── Podfile
    └── readyremitsdk.example.xcworkspace
```

### Key Example Code

```typescript
// example/src/App.tsx
const appearance: ReadyRemitAppearance = {
  foundations: {
    colorPrimary: { light: '#42CB91', dark: '#42CB91' },
    colorBackground: { light: '#F4F5F6', dark: '#111111' },
    fontFamily: 'inter',
  },
  components: {
    button: {
      buttonPrimaryBackgroundColor: { light: '#00766C', dark: '#20948A' },
      buttonRadius: 8,
    },
    content: {
      contentHomepageHeadline: 'Send money internationally',
      contentHomepageDescription: 'Send funds to your recipients with convenience and flexibility.',
    },
  },
};

startSDK({
  configuration: {
    environment: ReadyRemitEnvironment.Sandbox,
    appearance,
    supportedAppearance: ReadyRemitSupportedAppearance.Device,
  },
  fetchAccessTokenDetails,
  verifyFundsAndCreateTransfer,
});
```

---

## Building & Publishing

### Build the Package

```bash
# Build TypeScript and generate distribution files
yarn prepare

# This generates:
# - lib/module/       (ES modules)
# - lib/typescript/   (Type declarations)
```

### Create Distribution Tarball

```bash
# Pack for distribution
npm pack
# Creates: react-native-ready-remit-sdk-<version>.tgz
```

### Version Bump

Update version in `package.json`, then:

```bash
yarn prepare
npm pack
```

---

## Troubleshooting

### iOS Issues

**iOS Simulator only works on Apple Silicon Macs (M1/M2/M3):**
The ReadyRemit SDK XCFramework does not include x86_64 architecture for simulators. This means:
- Simulators will only work on Macs with Apple Silicon (arm64)
- Intel-based Macs must use a physical iOS device for testing
- When building, you may see "unsupported Swift architecture" errors if attempting to build for x86_64

To build for simulator on Apple Silicon:
```bash
xcodebuild -workspace YourApp.xcworkspace -scheme YourApp -configuration Debug -destination 'platform=iOS Simulator,name=iPhone 17,arch=arm64' build
```

**iOS Minimum Deployment Target:**
The SDK requires iOS 16.0 or higher. Update your Podfile:
```ruby
platform :ios, '16.0'
```

**Pod install fails with framework errors:**
```bash
cd example/ios
rm -rf Pods Podfile.lock
pod install --repo-update
```

**Swift header not found:**
Ensure `ReadyRemitSdkImpl` class has `@objc(ReadyRemitSdkImpl)` annotation.

### Android Issues

**Gradle sync fails:**
```bash
cd example/android
./gradlew clean
rm -rf .gradle
./gradlew --refresh-dependencies
```

**SDK not updating after changes:**
```bash
rm -rf ~/.gradle/caches/modules-2/files-2.1/io.github.brightwellpayments
rm -rf ~/.m2/repository/io/github/brightwellpayments
```

**Compose compiler errors:**
Ensure Kotlin version matches in all Gradle files (2.1.20).

### Metro Bundler Issues

```bash
# Clear Metro cache
cd example
yarn start --reset-cache
```

### TypeScript Not Updating

```bash
# Rebuild TypeScript
yarn prepare

# Clear example node_modules link
cd example
rm -rf node_modules/.cache
```
