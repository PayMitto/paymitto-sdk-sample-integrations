import type { ReadyRemitError, ReadyRemitTokenResponse, ReadyRemitTransferRequest, ReadyRemitTransferResponse } from "./types/ReadyRemit.types";
import type { ReadyRemitConfiguration } from "./types/ReadyRemitConfiguration.types";
declare class ReadyRemitSDK {
    private wrapper;
    /**
     * Initializes and starts the ReadyRemit SDK for money transfer operations.
     *
     * This method sets up the ReadyRemitSDK flow
     *
     * @param {Object} params - Configuration object for starting the SDK
     * @param {ReadyRemitConfiguration} params.configuration - SDK configuration including environment, customer credentials, and UI settings
     * @param {Function} params.fetchAccessTokenDetails - Async function to fetch authentication token
     * @param {Function} params.fetchAccessTokenDetails.returns - Promise that resolves to ReadyRemitTokenResponse on success or ReadyRemitError on failure
     * @param {Function} params.verifyFundsAndCreateTransfer - Async function to verify funds and create transfer
     * @param {ReadyRemitTransferRequest} params.verifyFundsAndCreateTransfer.request - Transfer request object containing transfer details
     * @param {Function} params.verifyFundsAndCreateTransfer.returns - Promise that resolves to ReadyRemitTransferResponse on success or ReadyRemitError on failure
     * @param {Function} [params.onLoad] - Optional callback executed when SDK is successfully loaded
     * @param {Function} [params.onClose] - Optional callback executed when SDK is closed
     *
     * @example
     * ```typescript
     * const sdk = new ReadyRemitSDK();
     *
     * sdk.startSDK({
     *   configuration: {
     *     environment: ReadyRemitEnvironment.SANDBOX,
     *     customerId: 'your-customer-id',
     *     customerSecret: 'your-customer-secret',
     *     senderId: 'your-sender-id'
     *   },
     *   fetchAccessTokenDetails: async () => {
     *     // Your authentication logic
     *     return await authService.getToken();
     *   },
     *   verifyFundsAndCreateTransfer: async (request) => {
     *     // Your transfer processing logic
     *     return await transferService.createTransfer(request);
     *   },
     *   onLoad: async () => {
     *     console.log('SDK loaded successfully');
     *   },
     *   onClose: async () => {
     *     console.log('SDK closed');
     *   }
     * });
     * ```
     *
     * @throws {Error} Throws error if configuration is invalid or SDK initialization fails
     * @since 1.0.0
     */
    startSDK({ configuration, fetchAccessTokenDetails, verifyFundsAndCreateTransfer, onLoad, onClose, }: {
        configuration: ReadyRemitConfiguration;
        fetchAccessTokenDetails: () => Promise<ReadyRemitTokenResponse | ReadyRemitError>;
        verifyFundsAndCreateTransfer: (request: ReadyRemitTransferRequest) => Promise<ReadyRemitTransferResponse | ReadyRemitError>;
        onLoad?: () => Promise<void>;
        onClose?: () => Promise<void>;
    }): void;
    /**
     * Starts the ReadyRemit SDK in transfer details view mode for a specific transfer.
     *
     * This method initializes the SDK to display details of an existing transfer.
     *
     * @param {Object} params - Configuration object for starting transfer details view
     * @param {string} params.transferId - Unique identifier of the transfer to display details for
     * @param {ReadyRemitConfiguration} params.configuration - SDK configuration including environment, customer credentials, and UI settings
     * @param {Function} params.fetchAccessTokenDetails - Async function to fetch authentication token
     * @param {Function} params.fetchAccessTokenDetails.returns - Promise that resolves to ReadyRemitTokenResponse on success or ReadyRemitError on failure
     * @param {Function} [params.onLoad] - Optional callback executed when SDK transfer details view is successfully loaded
     * @param {Function} [params.onClose] - Optional callback executed when SDK transfer details view is closed
     *
     * @example
     * ```typescript
     * const sdk = new ReadyRemitSDK();
     *
     * sdk.startTransferDetails({
     *   transferId: 'TXN123456789',
     *   configuration: {
     *     environment: ReadyRemitEnvironment.SANDBOX,
     *     customerId: 'your-customer-id',
     *     customerSecret: 'your-customer-secret',
     *     senderId: 'your-sender-id'
     *   },
     *   fetchAccessTokenDetails: async () => {
     *     // Your authentication logic
     *     return await authService.getToken();
     *   },
     *   onLoad: async () => {
     *     console.log('Transfer details loaded successfully');
     *   },
     *   onClose: async () => {
     *     console.log('Transfer details view closed');
     *   }
     * });
     * ```
     *
     * @throws {Error} Throws error if transferId is invalid, configuration is invalid, or SDK initialization fails
     * @since 1.0.0
     */
    startTransferDetails({ transferId, configuration, fetchAccessTokenDetails, onLoad, onClose, }: {
        transferId: string;
        configuration: ReadyRemitConfiguration;
        fetchAccessTokenDetails: () => Promise<ReadyRemitTokenResponse | ReadyRemitError>;
        onLoad?: () => Promise<void>;
        onClose?: () => Promise<void>;
    }): void;
    /**
     * Removes all event listeners and cleans up resources
     * Call this method when you're done using the SDK instance
     */
    removeAllListeners(): void;
}
export default ReadyRemitSDK;
//# sourceMappingURL=ReadyRemitSDK.d.ts.map