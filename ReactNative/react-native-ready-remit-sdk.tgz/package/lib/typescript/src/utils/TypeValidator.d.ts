import type { ReadyRemitError, ReadyRemitTokenResponse, ReadyRemitTransferResponse } from "../types/ReadyRemit.types";
export declare function isReadyRemitError(response: any): response is ReadyRemitError;
export declare function isReadyRemitTokenResponse(response: any): response is ReadyRemitTokenResponse;
export declare function isReadyRemitTransferResponse(response: any): response is ReadyRemitTransferResponse;
//# sourceMappingURL=TypeValidator.d.ts.map