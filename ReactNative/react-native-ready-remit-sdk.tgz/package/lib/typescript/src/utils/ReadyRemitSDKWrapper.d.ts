import { type EmitterSubscription } from 'react-native';
import type { ReadyRemitConfiguration } from '../types/ReadyRemitConfiguration.types';
import type { ReadyRemitError, ReadyRemitTokenResponse, ReadyRemitTransferResponse } from '../types/ReadyRemit.types';
export declare enum ReadyRemitSDKEvent {
    TOKEN_REQUESTED = "READYREMIT_AUTH_TOKEN_REQUESTED",
    TRANSFER_SUBMITTED = "READYREMIT_TRANSFER_SUBMITTED",
    SDK_LAUNCHED = "READYREMIT_SDK_LAUNCHED",
    SDK_CLOSED = "READYREMIT_SDK_CLOSED"
}
/**
 * Internal wrapper class for the native ReadyRemit module
 *
 * This class provides a TypeScript-friendly interface to the native iOS module,
 * handling event management and method calls to the native bridge.
 *
 * @internal - This class is not intended for direct client use
 */
declare class ReadyRemitModuleWrapper {
    private activeSubscriptions;
    /**
     * Starts the ReadyRemit SDK with the provided configuration
     * @param config - The SDK configuration object
     * @throws Error if config is invalid
     * @internal
     */
    startSDK(config: ReadyRemitConfiguration): void;
    /**
     * Starts the transfer details view for a specific transfer
     * @param config - The SDK configuration object
     * @param transferId - The unique identifier of the transfer to display
     * @throws Error if config is invalid or transferId is empty
     * @internal
     */
    startTransferDetails(config: ReadyRemitConfiguration, transferId: string): void;
    /**
     * Provides authentication response to the native module
     * @param success - Successful token response (if authentication succeeded)
     * @param failure - Error response (if authentication failed)
     * @throws Error if both success and failure are provided
     * @internal
     */
    setAuth(success?: ReadyRemitTokenResponse, failure?: ReadyRemitError): void;
    /**
     * Provides transfer response to the native module
     * @param success - Successful transfer response (if transfer succeeded)
     * @param failure - Error response (if transfer failed)
     * @throws Error if both success and failure are provided
     * @internal
     */
    setTransfer(success?: ReadyRemitTransferResponse, failure?: ReadyRemitError): void;
    /**
     * Adds an event listener for SDK events
     * @param event - The SDK event to listen for
     * @param onListen - Callback function to handle the event
     * @returns Subscription object that can be used to unsubscribe
     * @internal
     */
    addEventListener(event: ReadyRemitSDKEvent, onListen: (data: any) => void): EmitterSubscription;
    /**
     * Removes a specific event listener
     * @param subscription - The subscription to remove
     * @internal
     */
    removeEventListener(subscription: EmitterSubscription): void;
    /**
     * Removes all listeners for a specific event
     * @param event - The event to remove all listeners for
     * @internal
     */
    removeAllListenersForEvent(event: ReadyRemitSDKEvent): void;
    /**
     * Removes all event listeners and cleans up resources
     * @internal
     */
    removeAllListeners(): void;
    /**
     * Gets the count of active subscriptions for debugging
     * @returns Object with event names and subscription counts
     * @internal
     */
    getActiveSubscriptionsCount(): Record<string, number>;
    private validateConfiguration;
}
declare const ReadyRemitModuleWrapperSingleton: ReadyRemitModuleWrapper;
export default ReadyRemitModuleWrapperSingleton;
//# sourceMappingURL=ReadyRemitSDKWrapper.d.ts.map